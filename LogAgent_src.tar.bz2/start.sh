#!/bin/sh 

rm -f *.pid

./LogAgent -f conf/LogAgent.conf -D

