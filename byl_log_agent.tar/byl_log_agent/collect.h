#ifndef _COLLECT_H_
#define _COLLECT_H_

#include <iostream>
#include <fstream>
#include <string>

#include <pthread.h>

using namespace std;

class Collect {
public:
    Collect();
    ~Collect();
    
    int start();
    void stop();
    
    static void* task(void *args);
    
private:
    bool    _run;
	
	
	int open_file();
	int uuid_format(char *uuid_out, char *uuid_in);
	int trim_rn(string &in, string &out);
};

#endif
